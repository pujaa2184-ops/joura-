# JOURA — Journey of Reflection and Achievement

Prototype interaktif e-portfolio dialogis dengan konsep **World Map Adventure**.

## Fitur prototype
- Pemilihan mata pelajaran.
- Learning Journey Map dengan lima level.
- Submit: tambah tugas dan pilih file.
- Feedback: lihat contoh feedback dan kirim tanggapan.
- Revision: unggah revisi dan simpan catatan.
- Reflection: isi lima pertanyaan refleksi.
- My Learning Progress: Learning Growth Chart, Revision Improvement, dan Learning Achievement.
- Penyimpanan data prototype menggunakan browser Local Storage.

## Menjalankan di komputer
Pastikan Node.js sudah terpasang.

```bash
npm install
npm run dev
```

Buka alamat lokal yang ditampilkan Vite.

## Build untuk deployment
```bash
npm run build
```

Folder hasil build adalah `dist`.

## Deploy ke Vercel
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder proyek ini ke repository.
3. Impor repository tersebut ke Vercel.
4. Framework preset: Vite.
5. Build command: `npm run build`.
6. Output directory: `dist`.
7. Deploy.

## Catatan penting
Ini adalah prototype front-end. Data disimpan pada browser perangkat yang digunakan, bukan database online bersama. Data guru, akun siswa, sinkronisasi antarpengguna, dan penyimpanan file permanen belum tersedia. Untuk implementasi nyata, tambahkan backend, autentikasi, database, dan file storage.

Prototype website dapat dikemas menjadi aplikasi Android menggunakan Capacitor setelah website dan backend siap. Vercel digunakan untuk hosting website, bukan untuk membuat APK secara langsung.
