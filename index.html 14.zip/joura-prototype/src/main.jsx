import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowLeft, BookOpen, Check, ChevronRight, CircleHelp, CloudUpload,
  Compass, Crown, FileText, Flag, Gem, GraduationCap, Heart, Home,
  LockKeyhole, MessageCircle, Mountain, Pencil, Send, ShieldCheck,
  Sparkles, Star, Trophy, Upload, WandSparkles, X, Map, Menu, Award
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Area, AreaChart
} from "recharts";
import "./styles.css";

const LEVELS = [
  { id: 1, key: "submit", title: "SUBMIT", subtitle: "The Beginning", place: "Whispering Woods", icon: "📜", color: "mint", desc: "Kumpulkan dan simpan tugasmu di sini." },
  { id: 2, key: "feedback", title: "FEEDBACK", subtitle: "The Guidance", place: "Guidance Castle", icon: "🏰", color: "blue", desc: "Temukan arahan dan pesan dari gurumu." },
  { id: 3, key: "revision", title: "REVISION", subtitle: "The Improvement", place: "Crafting Workshop", icon: "🛠️", color: "peach", desc: "Sempurnakan pekerjaan berdasarkan feedback." },
  { id: 4, key: "reflection", title: "REFLECTION", subtitle: "The Reflection", place: "Reflection Lake", icon: "🌙", color: "lavender", desc: "Kenali proses dan pengalaman belajarmu." },
  { id: 5, key: "progress", title: "MY LEARNING PROGRESS", subtitle: "The Achievement", place: "Achievement Summit", icon: "🏔️", color: "gold", desc: "Lihat perjalanan dan pencapaian belajarmu." }
];

const REFLECTIONS = [
  "Apa yang kamu pelajari dari tugas ini?",
  "Kesulitan apa yang kamu hadapi saat menyelesaikan tugas ini?",
  "Bagian apa dari hasil pekerjaanmu yang menurutmu masih perlu diperbaiki?",
  "Bagaimana umpan balik yang diberikan membantumu memperbaiki hasil pekerjaanmu?",
  "Apa yang akan kamu lakukan secara berbeda ketika mengerjakan tugas berikutnya?"
];

const INITIAL_TASKS = [
  { id: 1, title: "Descriptive Text", subject: "Bahasa Inggris", date: "Pertemuan 1", type: "Dokumen", score: 65, feedback: "Your ideas are clear. Try to improve your grammar and add more specific details.", revisedScore: 85, status: "Reviewed" },
  { id: 2, title: "My Favorite Place — Video", subject: "Bahasa Inggris", date: "Pertemuan 2", type: "Video", score: 78, feedback: "Good presentation! Work on pronunciation and speaking fluency.", revisedScore: null, status: "Reviewed" },
  { id: 3, title: "Persuasive Speech", subject: "Bahasa Inggris", date: "Pertemuan 3", type: "Video", score: 82, feedback: "Strong argument. Add a clearer conclusion.", revisedScore: null, status: "Waiting for feedback" }
];

const SUBJECTS = ["Bahasa Inggris", "Matematika", "Sejarah", "Pendidikan Kewarganegaraan", "Biologi"];

function loadData() {
  try {
    const saved = localStorage.getItem("joura-prototype-v1");
    return saved ? JSON.parse(saved) : null;
  } catch { return null; }
}

function App() {
  const saved = loadData();
  const [subject, setSubject] = useState(saved?.subject || "");
  const [activeLevel, setActiveLevel] = useState(null);
  const [tasks, setTasks] = useState(saved?.tasks || INITIAL_TASKS);
  const [reflections, setReflections] = useState(saved?.reflections || {});
  const [replies, setReplies] = useState(saved?.replies || {});
  const [replyDraft, setReplyDraft] = useState("");
  const [selectedTask, setSelectedTask] = useState(1);
  const [toast, setToast] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    localStorage.setItem("joura-prototype-v1", JSON.stringify({ subject, tasks, reflections, replies }));
  }, [subject, tasks, reflections, replies]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(timer);
  }, [toast]);

  const completed = useMemo(() => {
    const result = new Set();
    if (tasks.length) result.add(1);
    if (tasks.some(t => t.feedback)) result.add(2);
    if (tasks.some(t => t.revisedScore)) result.add(3);
    if (Object.values(reflections).some(v => v && Object.keys(v).length === 5 && Object.values(v).every(x => x.trim()))) result.add(4);
    if (result.has(4)) result.add(5);
    return result;
  }, [tasks, reflections]);

  const notify = (message) => setToast(message);
  const goBack = () => setActiveLevel(null);

  function addTask(title, file) {
    const newTask = {
      id: Date.now(),
      title: title || file?.name || "New assignment",
      subject,
      date: `Tugas ${tasks.length + 1}`,
      type: file ? (file.type.startsWith("image/") ? "Gambar" : file.type.startsWith("video/") ? "Video" : file.type.startsWith("audio/") ? "Audio" : "Dokumen") : "Dokumen",
      score: null,
      feedback: "",
      revisedScore: null,
      status: "Submitted",
      fileName: file?.name || ""
    };
    setTasks(prev => [...prev, newTask]);
    notify("Tugas berhasil ditambahkan ke perjalananmu!");
  }

  function updateTask(id, changes) {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...changes } : t));
  }

  const task = tasks.find(t => t.id === selectedTask) || tasks[0];

  if (!subject) {
    return <SubjectPicker onSelect={setSubject} />;
  }

  if (activeLevel) {
    return (
      <div className="app-shell">
        <Topbar subject={subject} onHome={goBack} onSubject={() => { setSubject(""); setActiveLevel(null); }} />
        <main className="content-wrap">
          <button className="back-link" onClick={goBack}><ArrowLeft size={17}/> Kembali ke Learning Journey Map</button>
          {activeLevel === 1 && <SubmitPage tasks={tasks} onAdd={addTask} onSelectTask={setSelectedTask} />}
          {activeLevel === 2 && <FeedbackPage tasks={tasks} replies={replies} setReplies={setReplies} draft={replyDraft} setDraft={setReplyDraft} selectedTask={selectedTask} setSelectedTask={setSelectedTask} />}
          {activeLevel === 3 && <RevisionPage tasks={tasks} onUpdate={updateTask} selectedTask={selectedTask} setSelectedTask={setSelectedTask} notify={notify} />}
          {activeLevel === 4 && <ReflectionPage reflections={reflections} setReflections={setReflections} tasks={tasks} notify={notify} />}
          {activeLevel === 5 && <ProgressPage tasks={tasks} completed={completed} reflections={reflections} />}
        </main>
        <Toast message={toast}/>
      </div>
    );
  }

  return (
    <div className="app-shell map-shell">
      <Topbar subject={subject} onHome={() => {}} onSubject={() => setSubject("")} />
      <main className="map-page">
        <div className="map-heading">
          <div>
            <div className="eyebrow"><Sparkles size={14}/> YOUR LEARNING ADVENTURE</div>
            <h1>Your Learning Journey</h1>
            <p>Setiap langkah kecil membawamu menuju pencapaian baru.</p>
          </div>
          <div className="subject-chip"><BookOpen size={16}/>{subject}<span className="chip-dot"/></div>
        </div>
        <div className="journey-card">
          <div className="map-topline">
            <div><span className="map-label">WORLD 01</span><h2>The Land of Learning</h2></div>
            <div className="map-progress"><span>{completed.size}/5 LEVELS</span><div className="mini-progress"><i style={{width: `${completed.size/5*100}%`}}/></div></div>
          </div>
          <div className="world-map" aria-label="Learning Journey Map">
            <div className="sun-glow"/>
            <div className="cloud cloud-one">☁️</div><div className="cloud cloud-two">☁️</div><div className="cloud cloud-three">☁️</div>
            <div className="mountain-shape mountain-a">⛰️</div><div className="mountain-shape mountain-b">🌋</div>
            <div className="forest forest-a">🌲🌳🌲</div><div className="forest forest-b">🌳🌲🌳</div>
            <div className="river"/>
            <svg className="path-svg" viewBox="0 0 1000 540" preserveAspectRatio="none" aria-hidden="true">
              <path d="M115 400 C170 350 210 360 265 315 S360 240 435 275 S565 360 625 300 S720 190 790 210 S870 135 900 90" fill="none" stroke="#b68b55" strokeWidth="34" strokeLinecap="round" strokeDasharray="2 0"/>
              <path d="M115 400 C170 350 210 360 265 315 S360 240 435 275 S565 360 625 300 S720 190 790 210 S870 135 900 90" fill="none" stroke="#f9e4b9" strokeWidth="23" strokeLinecap="round" strokeDasharray="2 0"/>
              <path d="M115 400 C170 350 210 360 265 315 S360 240 435 275 S565 360 625 300 S720 190 790 210 S870 135 900 90" fill="none" stroke="#d8b17b" strokeWidth="2" strokeLinecap="round" strokeDasharray="7 12"/>
            </svg>
            <div className="map-deco deco-house">🏡</div><div className="map-deco deco-flowers">🌼 🌷</div>
            <div className="map-deco deco-bridge">🌉</div><div className="map-deco deco-crystal">💎</div>
            {LEVELS.map((level, i) => {
              const positions = [
                { left: "11.5%", top: "68%" },
                { left: "29%", top: "48%" },
                { left: "48%", top: "53%" },
                { left: "67%", top: "55%" },
                { left: "87%", top: "17%" }
              ];
              const done = completed.has(level.id);
              const locked = level.id > 1 && !completed.has(level.id - 1);
              return (
                <button key={level.id} className={`map-location ${level.color} ${done ? "is-done" : ""} ${locked ? "is-locked" : ""}`} style={positions[i]} onClick={() => locked ? notify("Selesaikan level sebelumnya untuk membuka lokasi ini.") : setActiveLevel(level.id)}>
                  <span className="location-number">{done ? <Check size={13}/> : level.id}</span>
                  <span className="location-art">{locked ? <LockKeyhole size={27}/> : level.icon}</span>
                  <span className="location-name">{level.title}</span>
                  <span className="location-status">{done ? "COMPLETED" : locked ? "LOCKED" : "EXPLORE"}</span>
                </button>
              );
            })}
            <div className="traveler" title="Your traveler">🧑🏻‍🎒</div>
            <div className="map-compass"><Compass size={24}/><small>N</small></div>
          </div>
          <div className="map-legend">
            <span><i className="legend-dot open"/> Available</span>
            <span><i className="legend-dot done"/> Completed</span>
            <span><i className="legend-dot locked"/> Locked</span>
            <span className="legend-tip"><Sparkles size={14}/> Pilih lokasi untuk memulai petualanganmu.</span>
          </div>
        </div>
        <div className="map-bottom">
          <div className="guide-card">
            <div className="guide-avatar">🧙🏻‍♀️</div>
            <div><strong>Welcome, Explorer!</strong><p>“Setiap tugas adalah langkah baru. Teruslah menjelajah dan berkembang!”</p></div>
          </div>
          <div className="quick-stats">
            <div><span className="stat-icon">📚</span><b>{tasks.length}</b><small>Tasks submitted</small></div>
            <div><span className="stat-icon">⭐</span><b>{completed.size}/5</b><small>Levels completed</small></div>
            <div><span className="stat-icon">🏅</span><b>{Math.min(3, completed.size)}</b><small>Achievements</small></div>
          </div>
        </div>
      </main>
      <Toast message={toast}/>
    </div>
  );
}

function SubjectPicker({ onSelect }) {
  return (
    <div className="subject-screen">
      <div className="subject-nav"><div className="brand-mark">J<span>✦</span></div><div className="brand-name">JOURA</div><span className="brand-tag">LEARN • REFLECT • GROW</span></div>
      <div className="subject-hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> YOUR LEARNING ADVENTURE STARTS HERE</div>
          <h1>Every learning step<br/><em>is an adventure.</em></h1>
          <p>Jelajahi perjalanan belajarmu, simpan setiap karya, dan rayakan setiap perkembangan bersama JOURA.</p>
          <div className="hero-bullets"><span><Check size={15}/> Save your work</span><span><Check size={15}/> Learn from feedback</span><span><Check size={15}/> Celebrate progress</span></div>
        </div>
        <div className="hero-art">
          <div className="hero-sun"/>
          <div className="hero-cloud c1">☁️</div><div className="hero-cloud c2">☁️</div>
          <div className="hero-hill hill-back"/><div className="hero-hill hill-front"/>
          <div className="hero-castle">🏰</div><div className="hero-tree t1">🌳</div><div className="hero-tree t2">🌲</div>
          <div className="hero-character">🧑🏻‍🎒</div><div className="hero-butterfly">🦋</div>
        </div>
      </div>
      <section className="subject-select">
        <div className="section-kicker">CHOOSE YOUR WORLD</div>
        <h2>Where would you like to explore?</h2>
        <p>Pilih mata pelajaran untuk memulai perjalanan belajarmu.</p>
        <div className="subject-grid">
          {SUBJECTS.map((s, i) => <button key={s} className={`subject-tile tile-${i}`} onClick={() => onSelect(s)}>
            <span className="subject-emoji">{["📘","🔢","🏛️","⚖️","🧬"][i]}</span><b>{s}</b><span className="tile-arrow"><ChevronRight size={17}/></span>
          </button>)}
        </div>
      </section>
      <footer className="subject-footer">JOURA © 2026 · Journey of Reflection and Achievement</footer>
    </div>
  );
}

function Topbar({ subject, onHome, onSubject }) {
  return <header className="topbar">
    <div className="topbar-left"><div className="brand-mark small">J<span>✦</span></div><div className="brand-name">JOURA</div><span className="top-divider"/><span className="top-subject">{subject}</span></div>
    <div className="topbar-right"><span className="explorer-pill">🧑🏻‍🎒 Explorer</span><button className="top-home" onClick={onSubject}><BookOpen size={16}/> Ganti mata pelajaran</button></div>
  </header>;
}

function PageTitle({ eyebrow, title, description, icon }) {
  return <div className="page-title"><div className="page-icon">{icon}</div><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div></div>;
}

function SubmitPage({ tasks, onAdd, onSelectTask }) {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState(null);
  const [showForm, setShowForm] = useState(false);
  function submit(e) { e.preventDefault(); if (!title.trim() && !file) return; onAdd(title.trim(), file); setTitle(""); setFile(null); setShowForm(false); }
  return <>
    <PageTitle eyebrow="LEVEL 01 · THE BEGINNING" title="Submit your work" description="Setiap karya adalah langkah pertama dalam perjalanan belajarmu." icon="📜"/>
    <div className="feature-banner mint-banner"><div><span className="banner-tag">QUEST BOARD</span><h2>Ready for a new quest?</h2><p>Unggah tugasmu dan simpan setiap hasil karya dalam satu perjalanan.</p><button className="primary-btn" onClick={() => setShowForm(v => !v)}><Upload size={16}/> Upload a task</button></div><div className="banner-illustration">📚<span>✨</span></div></div>
    {showForm && <form className="upload-panel" onSubmit={submit}>
      <div className="panel-heading"><h3>Upload your assignment</h3><button type="button" className="icon-btn" onClick={() => setShowForm(false)}><X size={18}/></button></div>
      <label>Nama tugas<input value={title} onChange={e => setTitle(e.target.value)} placeholder="Contoh: Descriptive Text"/></label>
      <label className="file-drop"><CloudUpload size={26}/><b>{file ? file.name : "Pilih file tugas"}</b><span>Dokumen, gambar, video, atau audio</span><input type="file" onChange={e => setFile(e.target.files?.[0] || null)} /></label>
      <button className="primary-btn" type="submit">Simpan tugas <ChevronRight size={16}/></button>
    </form>}
    <div className="section-head"><div><span className="section-kicker">YOUR COLLECTION</span><h2>My submitted tasks <span className="count-pill">{tasks.length}</span></h2></div><span className="sort-label">Urut berdasarkan tugas</span></div>
    <div className="task-list">{tasks.map((t, i) => <div className="task-card" key={t.id}><div className="task-file-icon">{t.type === "Video" ? "🎬" : t.type === "Gambar" ? "🖼️" : "📄"}</div><div className="task-info"><b>{t.title}</b><span>{t.date} · {t.type}{t.fileName ? ` · ${t.fileName}` : ""}</span></div><span className={`status-pill ${t.status === "Reviewed" ? "reviewed" : ""}`}>{t.status}</span><button className="outline-btn compact" onClick={() => onSelectTask(t.id)}>Details</button></div>)}</div>
  </>;
}

function FeedbackPage({ tasks, replies, setReplies, draft, setDraft, selectedTask, setSelectedTask }) {
  const selected = tasks.find(t => t.id === selectedTask) || tasks[0];
  function sendReply() { if (!draft.trim() || !selected) return; setReplies(prev => ({...prev, [selected.id]: [...(prev[selected.id] || []), {text: draft.trim(), from: "You"}]})); setDraft(""); }
  return <>
    <PageTitle eyebrow="LEVEL 02 · THE GUIDANCE" title="Feedback corner" description="Umpan balik adalah petunjuk untuk membantumu menemukan langkah berikutnya." icon="🏰"/>
    <div className="two-column">
      <div className="panel task-selector"><div className="panel-heading"><h3>Your assignments</h3><span className="count-pill">{tasks.length}</span></div>{tasks.map(t => <button key={t.id} className={`selector-item ${selected?.id === t.id ? "selected" : ""}`} onClick={() => setSelectedTask(t.id)}><span>📄</span><div><b>{t.title}</b><small>{t.date}</small></div><ChevronRight size={16}/></button>)}</div>
      <div className="panel feedback-panel"><div className="panel-heading"><div><span className="section-kicker">TEACHER'S MESSAGE</span><h3>{selected?.title || "No assignment yet"}</h3></div><span className="teacher-avatar">👩🏻‍🏫</span></div>
        {selected?.feedback ? <div className="teacher-note"><div className="note-label"><MessageCircle size={15}/> Feedback from your teacher</div><p>{selected.feedback}</p>{selected.score != null && <div className="score-line"><span>Current score</span><b>{selected.score}/100</b></div>}</div> : <div className="empty-state">💌<b>Belum ada feedback</b><span>Guru belum memberikan umpan balik untuk tugas ini.</span></div>}
        <div className="reply-area"><b>Your response</b><div className="reply-list">{(replies[selected?.id] || []).map((r,i) => <div className="reply-bubble" key={i}><b>{r.from}</b><p>{r.text}</p></div>)}</div><div className="reply-input"><input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Tulis tanggapan atau pertanyaan..."/><button onClick={sendReply} aria-label="Send reply"><Send size={17}/></button></div></div>
      </div>
    </div>
  </>;
}

function RevisionPage({ tasks, onUpdate, selectedTask, setSelectedTask, notify }) {
  const [file, setFile] = useState(null);
  const [note, setNote] = useState("");
  const selected = tasks.find(t => t.id === selectedTask) || tasks[0];
  function saveRevision() {
    if (!selected) return;
    onUpdate(selected.id, { revisedScore: selected.revisedScore ?? Math.min(100, (selected.score || 70) + 20), revisionFile: file?.name || "Revised submission", revisionNote: note, status: "Revised" });
    setFile(null); setNote(""); notify("Hasil revisi berhasil disimpan!");
  }
  return <>
    <PageTitle eyebrow="LEVEL 03 · THE IMPROVEMENT" title="Revision workshop" description="Perbaiki, kembangkan, dan jadikan feedback sebagai bekal untuk berkarya lebih baik." icon="🛠️"/>
    <div className="two-column revision-layout">
      <div className="panel task-selector"><div className="panel-heading"><h3>Select a task</h3></div>{tasks.map(t => <button key={t.id} className={`selector-item ${selected?.id === t.id ? "selected" : ""}`} onClick={() => setSelectedTask(t.id)}><span>📝</span><div><b>{t.title}</b><small>{t.revisedScore != null ? "Revised" : "Original submission"}</small></div><ChevronRight size={16}/></button>)}</div>
      <div className="panel">
        <div className="panel-heading"><div><span className="section-kicker">WORKBENCH</span><h3>{selected?.title || "Choose a task"}</h3></div><span className="workshop-icon">🔨</span></div>
        {selected && <><div className="compare-box"><div><small>ORIGINAL SCORE</small><b>{selected.score ?? "—"}</b></div><div className="compare-arrow">→</div><div><small>AFTER REVISION</small><b className="new-score">{selected.revisedScore ?? "—"}</b></div></div>
          <label className="file-drop revision-drop"><Upload size={24}/><b>{file ? file.name : selected.revisionFile || "Upload your revised work"}</b><span>Unggah hasil perbaikan tugas</span><input type="file" onChange={e => setFile(e.target.files?.[0] || null)}/></label>
          <label className="field-label">Catatan revisi<textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Ceritakan bagian yang kamu perbaiki..." rows={3}/></label>
          <button className="primary-btn" onClick={saveRevision}><WandSparkles size={16}/> Save revision</button>
        </>}
      </div>
    </div>
  </>;
}

function ReflectionPage({ reflections, setReflections, tasks, notify }) {
  const [chosen, setChosen] = useState(tasks[0]?.id || 1);
  const answers = reflections[chosen] || {};
  function change(i, value) { setReflections(prev => ({...prev, [chosen]: {...(prev[chosen] || {}), [i]: value}})); }
  function save() { notify("Refleksimu berhasil disimpan. Keep growing!"); }
  return <>
    <PageTitle eyebrow="LEVEL 04 · THE REFLECTION" title="Reflection lake" description="Berhenti sejenak, lihat kembali perjalananmu, dan temukan hal yang bisa dikembangkan." icon="🌙"/>
    <div className="reflection-intro"><span>🌿</span><div><b>A moment to reflect</b><p>Refleksi membantumu memahami proses belajar, bukan hanya hasil akhirnya.</p></div></div>
    <div className="panel reflection-panel">
      <label className="field-label">Pilih tugas untuk direfleksikan<select value={chosen} onChange={e => setChosen(Number(e.target.value))}>{tasks.map(t => <option key={t.id} value={t.id}>{t.title}</option>)}</select></label>
      <div className="reflection-questions">{REFLECTIONS.map((q,i) => <label className="question-card" key={i}><span className="question-number">{String(i+1).padStart(2,"0")}</span><span className="question-text">{q}</span><textarea rows={2} value={answers[i] || ""} onChange={e => change(i,e.target.value)} placeholder="Tuliskan refleksimu di sini..."/></label>)}</div>
      <div className="reflection-footer"><span>{Object.values(answers).filter(v => v.trim()).length}/5 pertanyaan terjawab</span><button className="primary-btn" onClick={save}><Check size={16}/> Save reflection</button></div>
    </div>
  </>;
}

function ProgressPage({ tasks, completed, reflections }) {
  const scores = tasks.filter(t => t.score != null).map((t,i) => ({name: `Task ${i+1}`, score: t.score, revised: t.revisedScore}));
  const revisedTasks = tasks.filter(t => t.score != null && t.revisedScore != null);
  const reflectionCompleted = Object.values(reflections).some(v => v && Object.keys(v).length === 5 && Object.values(v).every(x => x.trim()));
  const badges = [
    {name:"First Step", desc:"Mengumpulkan tugas pertama", icon:"📜", earned:tasks.length>0},
    {name:"Feedback Seeker", desc:"Membaca dan menanggapi feedback", icon:"💌", earned:tasks.some(t=>t.feedback)},
    {name:"Revision Rookie", desc:"Menyelesaikan revisi pertama", icon:"🛠️", earned:revisedTasks.length>0},
    {name:"Reflection Master", desc:"Menyelesaikan lima refleksi", icon:"🌙", earned:reflectionCompleted}
  ];
  return <>
    <PageTitle eyebrow="LEVEL 05 · THE ACHIEVEMENT" title="My learning progress" description="Lihat seberapa jauh kamu telah melangkah dan rayakan setiap perkembangan." icon="🏔️"/>
    <div className="progress-summary"><div><span className="summary-icon">🌟</span><small>YOUR JOURNEY</small><b>{completed.size}/5</b><span>Levels explored</span></div><div><span className="summary-icon">📚</span><small>YOUR COLLECTION</small><b>{tasks.length}</b><span>Tasks submitted</span></div><div><span className="summary-icon">🏅</span><small>YOUR TROPHIES</small><b>{badges.filter(b=>b.earned).length}</b><span>Badges earned</span></div></div>
    <div className="panel chart-panel"><div className="section-head"><div><span className="section-kicker">A JOURNEY OF GROWTH</span><h2>Learning Growth Chart</h2><p>Perkembangan nilai dari tugas ke tugas.</p></div><span className="chart-key"><i/> Score</span></div>
      <div className="chart-wrap">{scores.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={scores} margin={{top:10,right:15,left:-18,bottom:0}}><defs><linearGradient id="scoreFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#78bca2" stopOpacity={0.32}/><stop offset="100%" stopColor="#78bca2" stopOpacity={0.02}/></linearGradient></defs><CartesianGrid strokeDasharray="4 5" stroke="#eee5d7"/><XAxis dataKey="name" tick={{fill:"#8a8379",fontSize:12}} axisLine={false} tickLine={false}/><YAxis domain={[0,100]} tick={{fill:"#8a8379",fontSize:12}} axisLine={false} tickLine={false}/><Tooltip/><Area type="monotone" dataKey="score" stroke="#4f9b80" strokeWidth={3} fill="url(#scoreFill)" activeDot={{r:6}}/></AreaChart></ResponsiveContainer> : <div className="empty-chart">📈<b>Belum ada data nilai</b><span>Nilai akan muncul setelah guru memberikan penilaian.</span></div>}</div>
    </div>
    <div className="two-column progress-bottom">
      <div className="panel"><div className="section-head"><div><span className="section-kicker">BEFORE & AFTER</span><h2>Revision Improvement</h2></div></div>
        {revisedTasks.length ? revisedTasks.map(t=><div className="revision-result" key={t.id}><b>{t.title}</b><div className="score-compare"><span>{t.score}</span><ChevronRight size={17}/><strong>{t.revisedScore}</strong><em>+{t.revisedScore-t.score} points</em></div></div>) : <div className="empty-state small-empty">🛠️<b>Belum ada hasil revisi</b><span>Nilai sebelum dan sesudah revisi akan ditampilkan di sini.</span></div>}
      </div>
      <div className="panel"><div className="section-head"><div><span className="section-kicker">CELEBRATE YOUR MILESTONES</span><h2>Learning Achievement</h2></div></div>
        <div className="badge-grid">{badges.map(b=><div className={`badge-item ${b.earned?"earned":""}`} key={b.name}><span>{b.icon}</span><b>{b.name}</b><small>{b.desc}</small><i>{b.earned?"UNLOCKED":"NOT YET"}</i></div>)}</div>
      </div>
    </div>
  </>;
}

function Toast({ message }) { return message ? <div className="toast"><Check size={17}/>{message}</div> : null; }

createRoot(document.getElementById("root")).render(<App />);
